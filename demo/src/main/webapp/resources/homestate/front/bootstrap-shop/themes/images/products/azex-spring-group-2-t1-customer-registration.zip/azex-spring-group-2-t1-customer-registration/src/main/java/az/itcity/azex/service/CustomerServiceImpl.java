package az.itcity.azex.service;

import az.itcity.azex.domain.Customer;
import az.itcity.azex.domain.Order;
import org.springframework.stereotype.Service;

import javax.xml.ws.ServiceMode;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.Month;

@Service
public class CustomerServiceImpl implements CustomerService {

    @Override
    public Customer getCustomer(long id) {
        Customer customer = new Customer();
        customer.setId(id);
        customer.setName("Ali");
        customer.setSurname("Mammadov");
        customer.setBirthDate(LocalDate.of(1988, Month.DECEMBER, 15));
        customer.setRegistrationDate(LocalDateTime.now());

        customer.getOrderList().add(new Order(1, "link1", BigDecimal.valueOf(100), LocalDateTime.now()));
        customer.getOrderList().add(new Order(2, "link2", BigDecimal.valueOf(50), LocalDateTime.now()));
        customer.getOrderList().add(new Order(3, "link3", BigDecimal.valueOf(33), LocalDateTime.now()));
        customer.getOrderList().add(new Order(4, "link4", BigDecimal.valueOf(44), LocalDateTime.now()));

        return customer;
    }
}
