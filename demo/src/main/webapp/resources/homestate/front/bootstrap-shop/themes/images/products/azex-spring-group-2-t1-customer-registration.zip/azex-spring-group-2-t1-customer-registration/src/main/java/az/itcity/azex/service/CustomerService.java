package az.itcity.azex.service;

import az.itcity.azex.domain.Customer;

public interface CustomerService {

    Customer getCustomer(long id);
}
