package az.itcity.azex.controller;

import az.itcity.azex.domain.Customer;
import az.itcity.azex.domain.Order;
import az.itcity.azex.service.CustomerService;
import az.itcity.azex.web.ActivationForm;
import az.itcity.azex.web.ActivationFormValidator;
import az.itcity.azex.web.RegistrationForm;
import az.itcity.azex.web.RegistrationFormValidator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.Month;

@RequestMapping("/")
@Controller
public class IndexController {

    @Autowired
    private RegistrationFormValidator registrationFormValidator;

    @Autowired
    private ActivationFormValidator activationFormValidator;

    @Autowired
    private CustomerService customerService;

//    @InitBinder
//    protected void initBinder(WebDataBinder dataBinder) {
//        // Form target
//        Object target = dataBinder.getTarget();
//        if (target == null) {
//            return;
//        }
//
//        if (target.getClass() == RegistrationForm.class) {
//            dataBinder.setValidator(registrationFormValidator);
//        }
//
//        if(target.getClass() == ActivationForm.class){
//            dataBinder.setValidator(activationFormValidator);
//        }
//    }

    @GetMapping(value = {"/", "/index", "/home"})
    public String index() {
        return "index";
    }


    @GetMapping("/test")
    public String test() {
        return "index";
    }

//    @GetMapping("/register")
//    public String register() {
//        return "register";
//    }

    @GetMapping("/register")
    public ModelAndView register() {
        ModelAndView mav = new ModelAndView("register");
        RegistrationForm form = new RegistrationForm();
//        form.setFirstName("Ali");
//        form.setLastName("Mammadov");
//        form.setEmail("ali.mammadov@gmail.com");
        mav.addObject("registrationForm", form);
        return mav;
    }

    @PostMapping("/register")
    public ModelAndView registerCustomer(
            Model model,
            @ModelAttribute("registrationForm") @Validated RegistrationForm form,
            BindingResult validationResult
    ) {

        ModelAndView mav = new ModelAndView();

        if(validationResult.hasErrors()) {
            mav.setViewName("register");

            System.out.println("xetalarin sayi = " + validationResult.getErrorCount());
            System.out.println("xetalar = ");
            validationResult.getAllErrors().forEach(System.out::println);

        } else {
            System.out.println("registration form = " + form);
            // TODO implement registration
            mav.setViewName("/register-success");
        }

        return mav;
    }

//    @PostMapping("/register")
//    public ModelAndView registerCustomer(
//        @RequestParam(name = "first_name") String firstName,
//        @RequestParam(name = "last_name") String lastName,
//        @RequestParam(name = "email") String email,
//        @RequestParam(name = "password") String password,
//        @RequestParam(name = "password_confirmation") String passwordConfirmation
//    ) {
//        ModelAndView mav = new ModelAndView("register-success");
//
//        System.out.println("firstName = " + firstName);
//        System.out.println("lastName = " + lastName);
//        System.out.println("email = " + email);
//        System.out.println("password = " + password);
//        System.out.println("password_confirmation = " + passwordConfirmation);
//        return mav;
//    }

    @GetMapping("/activate")
    public ModelAndView activateUser(){
        ModelAndView mav = new ModelAndView("activate");
        mav.addObject("activationForm", new ActivationForm());
        return mav;
    }

    @PostMapping("/activate")
    public ModelAndView activateCustomer(
            Model model,
            @ModelAttribute("activationForm") @Validated ActivationForm form,
            BindingResult result
    ){
        ModelAndView mav = new ModelAndView();

        if(result.hasErrors()){
            mav.setViewName("activate");

            System.out.println("Xetalarin sayi: " + result.getErrorCount());
            System.out.println("Xetalar");
            result.getAllErrors().forEach(System.out::println);

        }else {
            System.out.println("activation form " + form);

            mav.setViewName("/activation-success");
        }
        return mav;
    }

    @GetMapping("/search")
    @ResponseBody
    public Customer getCustomer(@RequestParam(name="id") long id) {
        Customer customer = customerService.getCustomer(id);

        System.out.println("response body customer = " + customer);

        return customer;
    }

//    @GetMapping("/search-new/{id}/order/{orderId}")
    @GetMapping("/search-new/{id}")
    public ResponseEntity<Customer> getCustomerNew(@PathVariable(name="id") long customerId
//            ,@PathVariable(name="orderId") long orderId) {
            ) {
        Customer customer = customerService.getCustomer(customerId);
        System.out.println("response entity customer = " + customer);
//        return ResponseEntity.ok(customer);
        return new ResponseEntity<>(customer, HttpStatus.BAD_REQUEST);

    }


}
