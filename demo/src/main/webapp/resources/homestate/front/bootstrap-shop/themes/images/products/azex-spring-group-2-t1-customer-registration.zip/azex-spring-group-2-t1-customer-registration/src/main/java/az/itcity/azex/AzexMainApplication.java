package az.itcity.azex;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AzexMainApplication {

    public static void main(String[] args) {
        SpringApplication.run(AzexMainApplication.class, args);
    }
}
