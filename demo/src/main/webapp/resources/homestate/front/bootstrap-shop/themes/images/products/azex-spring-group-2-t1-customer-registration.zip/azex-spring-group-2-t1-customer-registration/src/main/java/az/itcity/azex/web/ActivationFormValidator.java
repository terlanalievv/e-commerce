package az.itcity.azex.web;

import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

@Component
public class ActivationFormValidator implements Validator {


    @Override
    public boolean supports(Class<?> aClass) {
        return aClass.equals(ActivationForm.class);
    }

    @Override
    public void validate(Object o, Errors errors) {

        ActivationForm activationForm = (ActivationForm) o;

        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "pinCode", "activate.pinCode.required");
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "idCardNum", "activate.idCardNum.required");




    }
}
