package az.itcity.azex.web;

import java.io.Serializable;

public class ActivationForm  implements Serializable {

    private static final long serialVersionUID = -7701333074940101806L;

    private String pinCode;
    private String idCardNum;
    private String mobilePhoneNum;
    private String birthDate;
    private int city;
    private int district;
    private int channel;
    private String address;
    private int gender;


    public ActivationForm(String pinCode, String idCardNum, String mobilePhoneNum, String birthDate, int city, int district, int channel, String address, int gender) {
        this.pinCode = pinCode;
        this.idCardNum = idCardNum;
        this.mobilePhoneNum = mobilePhoneNum;
        this.birthDate = birthDate;
        this.city = city;
        this.district = district;
        this.channel = channel;
        this.address = address;
        this.gender = gender;
    }


    public ActivationForm() {
    }

    public String getPinCode() {
        return pinCode;
    }

    public void setPinCode(String pinCode) {
        this.pinCode = pinCode;
    }

    public String getIdCardNum() {
        return idCardNum;
    }

    public void setIdCardNum(String idCardNum) {
        this.idCardNum = idCardNum;
    }

    public String getMobilePhoneNum() {
        return mobilePhoneNum;
    }

    public void setMobilePhoneNum(String mobilePhoneNum) {
        this.mobilePhoneNum = mobilePhoneNum;
    }

    public String getBirthDate() {
        return birthDate;
    }

    public void setBirthDate(String birthDate) {
        this.birthDate = birthDate;
    }

    public int getCity() {
        return city;
    }

    public void setCity(int city) {
        this.city = city;
    }

    public int getDistrict() {
        return district;
    }

    public void setDistrict(int district) {
        this.district = district;
    }

    public int getChannel() {
        return channel;
    }

    public void setChannel(int channel) {
        this.channel = channel;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public int getGender() {
        return gender;
    }

    public void setGender(int gender) {
        this.gender = gender;
    }


    @Override
    public String toString() {
        return "ActivationForm{" +
                "pinCode='" + pinCode + '\'' +
                ", idCardNum='" + idCardNum + '\'' +
                ", mobilePhoneNum='" + mobilePhoneNum + '\'' +
                ", birthDate='" + birthDate + '\'' +
                ", city=" + city +
                ", district=" + district +
                ", channel=" + channel +
                ", address='" + address + '\'' +
                ", gender=" + gender +
                '}';
    }
}
